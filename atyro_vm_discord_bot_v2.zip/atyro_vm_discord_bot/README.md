# Atyro VM Discord Manager v2

Professional Discord management bot for multiple `hopingboyz/atyro-ubuntu24` KVM VMs.

## Included

- `!vm <ram> <cpu> <disk> @user`
- 28-day VM leases
- `!renew @user`
- `!delete @user`
- `!manage [@user]`
- `!vminfo`
- `!setadmin @user` / `!adminset @user`
- `!removeadmin @user`
- Automatic VM-owner role assignment
- Automatic bot-admin role assignment
- GG reaction on admin/VM-owner `!` commands
- Owner-only SSHX / Restart / Reinstall buttons
- Rich TEMPEST CLOUD telemetry embeds
- CPU, RAM and `/vm` disk usage
- KVM/QEMU status
- Automatic unique SSH/VNC ports
- 28/7/3/1-day expiry DM notifications
- Expiry stop handling
- Delete cleanup + role removal + owner DM
- SQLite persistence
- `.env` loading with `python-dotenv`

## SSHX fix

The VM image does not ship with SSHX. On first use, the bot installs the official SSHX client from `sshx.io`, then launches it through a pseudo-terminal using `script`, so the shared terminal is interactive instead of being a non-TTY process.

Official SSHX installation documentation: `curl -sSf https://sshx.io/get | sh`

## Required Discord IDs

- Main bot owner: `1447083500720230401`
- VM owner role: `1545501965562159116`
- Bot admin role: `1546053390528811120`
- GG reaction: `1519587770425933824`

## Install

```bash
cd /opt/zero-bot/atyro-bot/atyro_vm_discord_bot
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
python3 bot.py
```

Set at least:

```env
DISCORD_TOKEN=YOUR_DISCORD_BOT_TOKEN
PUBLIC_IP=YOUR_SERVER_PUBLIC_IP
```

Do not share the bot token.

## Docker requirements

The bot must run on the Docker host and have access to:

```text
/var/run/docker.sock
/dev/kvm
```

The bot creates privileged Atyro containers and maps unique host ports starting at SSH `2026` and VNC `6080`.

## Commands

### Admin

```text
!vm 2 1 50 @user
!renew @user
!delete @user
!manage @user
!vminfo
!setadmin @user
!adminset @user
!removeadmin @user
```

### VM owner

```text
!manage
```

The management console includes:

- SSHX
- Restart
- Reinstall OS
- Refresh

Only the VM owner can click these VM-control buttons. Admins can open `!manage @user` to inspect the VM, but owner-only buttons remain protected.

## Important

Put the bot's Discord role above:

- role `1545501965562159116`
- role `1546053390528811120`

and grant the bot **Manage Roles** so automatic role assignment/removal works.
