# ATYRO VM Discord Bot - Fixed

This version uses `hopingboyz/atyro-ubuntu24` and fixes SSHX so the browser terminal connects to the Ubuntu/QEMU guest instead of the Docker wrapper shell.

## Install

```bash
cd /root/Ay/atyro_vm_discord_bot
source /root/Ay/venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
python -m py_compile bot.py
python -u bot.py
```

## Commands

- `!vm <ram> <cpu> <disk> @user`
- `!manage [@user]`
- `!renew @user`
- `!delete @user`
- `!vminfo`
- `!setadmin @user`
- `!adminset @user`
- `!removeadmin @user`

SSHX from Manage starts:

```text
ssh -tt -p 2222 root@127.0.0.1
```

inside the Atyro wrapper, so the SSHX terminal is the actual Ubuntu guest. `apt` will work there.
