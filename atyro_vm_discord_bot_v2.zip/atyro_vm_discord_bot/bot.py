import asyncio
import io
import os
import re
import sqlite3
import time
import uuid
import shlex
from datetime import datetime, timedelta, timezone
from pathlib import Path

from dotenv import load_dotenv
load_dotenv()

import discord
from discord.ext import commands, tasks
import docker
from docker.errors import APIError, DockerException, NotFound

# ============================================================
# Atyro VM Discord Manager
# Docker host bot for hopingboyz/atyro-ubuntu24
# ============================================================

TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
PREFIX = os.getenv("PREFIX", "!")
DB_PATH = os.getenv("DB_PATH", "./atyro.db")
IMAGE = os.getenv("ATYRO_IMAGE", "hopingboyz/atyro-ubuntu24")
SSH_BASE = int(os.getenv("SSH_BASE_PORT", "2026"))
VNC_BASE = int(os.getenv("VNC_BASE_PORT", "6080"))
PUBLIC_IP = os.getenv("PUBLIC_IP", "").strip()
SSHX_TIMEOUT = int(os.getenv("SSHX_TIMEOUT", "20"))
DEFAULT_DAYS = int(os.getenv("VM_DAYS", "28"))
MAX_RAM_GB = int(os.getenv("MAX_RAM_GB", "32"))
MAX_CPU = int(os.getenv("MAX_CPU", "16"))
MAX_DISK_GB = int(os.getenv("MAX_DISK_GB", "500"))
OWNER_ROLE = os.getenv("OWNER_ROLE", "").strip()  # optional role allowed to use owner commands
LOG_CHANNEL_ID = int(os.getenv("LOG_CHANNEL_ID", "0") or 0)
# Main bot administrator / server owner
BOT_OWNER_ID = int(os.getenv("BOT_OWNER_ID", "1447083500720230401"))
# Role automatically granted to every VM owner
VM_OWNER_ROLE_ID = int(os.getenv("VM_OWNER_ROLE_ID", "1545501965562159116"))
# Role automatically granted to Atyro bot admins
BOT_ADMIN_ROLE_ID = int(os.getenv("BOT_ADMIN_ROLE_ID", "1546053390528811120"))
GG_REACTION = "<a:GG:1519587770425933824>"

# ----------------- CUSTOM EMOJIS -----------------
E_ONLINE = "<a:Online:1519557436854370334>"
E_OFFLINE = "<a:offline:1519557662977822941>"
E_LOADING = "<a:loading_icon:1520088258027982858>"
E_LOADING_ALT = "<a:Loading:1519558138209112155>"
E_LIGHTNING = "<a:65023lightning:1519762787579072593>"
E_THUNDER = "<a:thunder:1519558414353698927>"
E_FIRE = "<a:fire:1520089278225453186>"
E_GEAR = "<a:PurpleGear:1545024403216269395>"
E_YES = "<a:yes:1519555946312106024>"
E_CHECK = "<a:greencheck:1519588992767496193>"
E_NO = "<a:vote_no:1519763086570164246>"
E_WARN = "<a:Warning:1519588395620499648>"
E_DOWN = "<a:DOWN:1520088811399413850>"
E_ARROW = "<a:arrow:1519556344951341156>"
E_ARROW_DOUBLE = "<a:arrow:1519556677173510325>"
E_LEFT_ARROW = "<a:leftarrow:1519585449713074226>"
E_STAR = "<a:star:1519557024801751051>"
E_BLACK_WING = "<a:blackWing1:1545024935016144947>"
E_KING_CROWN = "<a:King_crown:1519766073560403990>"
E_MOD = "<:ModeratorRoleIcon:1545029625405505586>"
E_BOT_TAG = "<:bot_tag:1519559016013889647>"
E_INFO = "<:Information:1545028101501747230>"
E_GG = "<a:GG:1519587770425933824>"
E_PROFILE = "<:profil:1520088044970180638>"
E_WAVES = "<a:waves:1520088703811326122>"
E_COIN = "<a:coin:1519767909847535750>"
E_CART = "<a:shopping_cart:1545024782016192612>"
E_MONEY = "<:money:1545027262229774389>"
E_CLYDE = "<:clyde_bot:1539693513837514885>"
E_VOTE_YES = "<a:vote_yes:1519763256992993422>"

E = {
    "yes": E_YES, "arrow": E_ARROW, "arrow2": E_ARROW_DOUBLE, "star": E_STAR,
    "online": E_ONLINE, "offline": E_OFFLINE, "loading": E_LOADING_ALT,
    "thunder": E_THUNDER, "bot": E_BOT_TAG, "warning": E_WARN, "green": E_CHECK,
    "lightning": E_LIGHTNING, "no": E_NO, "vote": E_VOTE_YES, "crown": E_KING_CROWN,
    "coin": E_COIN, "profile": E_PROFILE, "loading2": E_LOADING, "waves": E_WAVES,
    "down": E_DOWN, "fire": E_FIRE, "gear": E_GEAR, "cart": E_CART,
    "info": E_INFO, "money": E_MONEY, "blackwing": E_BLACK_WING, "mod": E_MOD,
    "left": E_LEFT_ARROW, "gg": E_GG,
}
GG_REACTION = E_GG

def now():
    return datetime.now(timezone.utc)

def iso(dt):
    return dt.astimezone(timezone.utc).isoformat()

def parse_iso(s):
    return datetime.fromisoformat(s)

def human_dt(s):
    return parse_iso(s).astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")

def vm_name(vm):
    return vm["container"]

def public_ip():
    return PUBLIC_IP or os.getenv("SERVER_PUBLIC_IP", "YOUR_SERVER_PUBLIC_IP")

def clamp_int(v, lo, hi):
    return max(lo, min(hi, v))

# ---------------- Database ----------------

db = sqlite3.connect(DB_PATH, check_same_thread=False)
db.row_factory = sqlite3.Row
db.execute("""
CREATE TABLE IF NOT EXISTS vms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL UNIQUE,
    container TEXT NOT NULL UNIQUE,
    volume TEXT NOT NULL UNIQUE,
    ram_gb INTEGER NOT NULL,
    cpu INTEGER NOT NULL,
    disk_gb INTEGER NOT NULL,
    ssh_port INTEGER NOT NULL UNIQUE,
    vnc_port INTEGER NOT NULL UNIQUE,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'creating'
)
""")
db.execute("""
CREATE TABLE IF NOT EXISTS admins (
    user_id INTEGER PRIMARY KEY,
    added_at TEXT NOT NULL
)
""")
db.execute("""
CREATE TABLE IF NOT EXISTS expiry_notices (
    vm_id INTEGER NOT NULL,
    days INTEGER NOT NULL,
    sent_at TEXT NOT NULL,
    PRIMARY KEY (vm_id, days)
)
""")
db.commit()

def db_one(sql, args=()):
    return db.execute(sql, args).fetchone()

def db_all(sql, args=()):
    return db.execute(sql, args).fetchall()

def get_vm(owner_id):
    return db_one("SELECT * FROM vms WHERE owner_id=?", (owner_id,))

def get_vm_by_id(vm_id):
    return db_one("SELECT * FROM vms WHERE id=?", (vm_id,))

def add_vm(owner_id, container, volume, ram, cpu, disk, ssh, vnc, created, expires):
    db.execute("""INSERT INTO vms
        (owner_id,container,volume,ram_gb,cpu,disk_gb,ssh_port,vnc_port,created_at,expires_at,status)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (owner_id, container, volume, ram, cpu, disk, ssh, vnc, created, expires, "creating"))
    db.commit()

def set_status(vm_id, status):
    db.execute("UPDATE vms SET status=? WHERE id=?", (status, vm_id))
    db.commit()

def delete_db_vm(vm_id):
    db.execute("DELETE FROM vms WHERE id=?", (vm_id,))
    db.commit()

# ---------------- Docker ----------------

try:
    docker_client = docker.from_env()
    docker_client.ping()
except Exception as exc:
    raise SystemExit(
        "Cannot connect to Docker. Run the bot on the Docker host and mount "
        "/var/run/docker.sock. Error: " + str(exc)
    )

def container_obj(vm):
    return docker_client.containers.get(vm["container"])

def container_running(vm):
    try:
        return container_obj(vm).status == "running"
    except NotFound:
        return False

def port_free(port):
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("0.0.0.0", port))
        return True
    except OSError:
        return False
    finally:
        s.close()

def allocate_ports():
    used = set()
    for row in db_all("SELECT ssh_port, vnc_port FROM vms"):
        used.update([row["ssh_port"], row["vnc_port"]])
    ssh = SSH_BASE
    vnc = VNC_BASE
    while ssh in used or not port_free(ssh):
        ssh += 1
    while vnc in used or not port_free(vnc):
        vnc += 1
    return ssh, vnc

def make_container(vm):
    return docker_client.containers.run(
        IMAGE,
        name=vm["container"],
        detach=True,
        privileged=True,
        devices=["/dev/kvm:/dev/kvm"],
        environment={
            "RAM": str(vm["ram_gb"] * 1024),
            "CPU": str(vm["cpu"]),
            "DISK": str(vm["disk_gb"]),
            "VNC_PASS": os.getenv("VNC_PASS", "admin"),
            "ROOT_PASS": os.getenv("ROOT_PASS", "admin"),
        },
        ports={
            "2222/tcp": ("0.0.0.0", vm["ssh_port"]),
            "6080/tcp": ("0.0.0.0", vm["vnc_port"]),
        },
        volumes={vm["volume"]: {"bind": "/vm", "mode": "rw"}},
        restart_policy={"Name": "unless-stopped"},
        labels={
            "atyro.manager": "discord",
            "atyro.owner": str(vm["owner_id"]),
            "atyro.vm_id": str(vm["id"]),
        },
    )

# ---------------- Embed helpers ----------------

def embed(title, description="", color=0x8B5CF6):
    em = discord.Embed(title=title, description=description, color=color, timestamp=now())
    em.set_footer(text="Atyro VM Manager")
    return em

async def send_log(message):
    if LOG_CHANNEL_ID:
        ch = bot.get_channel(LOG_CHANNEL_ID)
        if ch:
            try:
                await ch.send(embed=message)
            except Exception:
                pass

def progress_embed(title, text):
    return embed(f"{E['loading']} {title}", text, 0x8B5CF6)

# ---------------- Bot ----------------

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)

def is_admin(member):
    if member.id == BOT_OWNER_ID:
        return True
    if member.guild_permissions.administrator:
        return True
    if db_one("SELECT user_id FROM admins WHERE user_id=?", (member.id,)):
        return True
    if OWNER_ROLE and any(r.name == OWNER_ROLE for r in member.roles):
        return True
    return False

def admin_only():
    async def predicate(ctx):
        if not is_admin(ctx.author):
            raise commands.CheckFailure("admin")
        return True
    return commands.check(predicate)

async def owner_or_admin(ctx, owner_id):
    return ctx.author.id == owner_id or is_admin(ctx.author)

async def grant_role(member: discord.Member, role_id: int):
    """Grant a configured role safely; missing role/permissions are non-fatal."""
    if not role_id or not member.guild:
        return False
    role = member.guild.get_role(role_id)
    if role is None:
        try:
            role = await member.guild.fetch_role(role_id)
        except Exception:
            return False
    if role in member.roles:
        return True
    try:
        await member.add_roles(role, reason="Atyro VM Bot automatic role assignment")
        return True
    except (discord.Forbidden, discord.HTTPException):
        return False

async def remove_role(member: discord.Member, role_id: int):
    if not role_id or not member.guild:
        return False
    role = member.guild.get_role(role_id)
    if role is None:
        return False
    try:
        if role in member.roles:
            await member.remove_roles(role, reason="Atyro VM Bot admin role removal")
        return True
    except (discord.Forbidden, discord.HTTPException):
        return False

@bot.event
async def on_message(message):
    if message.author.bot:
        return
    is_atyro_command = message.content.startswith(PREFIX)
    author_is_admin = isinstance(message.author, discord.Member) and is_admin(message.author)
    author_is_vm_owner = isinstance(message.author, discord.Member) and get_vm(message.author.id) is not None

    await bot.process_commands(message)

    # Confirm Atyro commands used by admins or VM owners with the requested animated GG reaction.
    if is_atyro_command and (author_is_admin or author_is_vm_owner):
        try:
            await message.add_reaction(GG_REACTION)
        except (discord.Forbidden, discord.HTTPException):
            pass

# ---------------- Usage ----------------

def get_usage(vm):
    try:
        c = container_obj(vm)
        if c.status != "running":
            return {"cpu": 0.0, "ram_mb": 0, "ram_limit_mb": vm["ram_gb"]*1024, "disk_gb": 0.0}
        st = c.stats(stream=False)
        mem = st.get("memory_stats", {})
        usage = int(mem.get("usage", 0))
        limit = int(mem.get("limit", vm["ram_gb"]*1024*1024*1024))
        cpu_delta = st.get("cpu_stats", {}).get("cpu_usage", {}).get("total_usage", 0) - \
                    st.get("precpu_stats", {}).get("cpu_usage", {}).get("total_usage", 0)
        sys_delta = st.get("cpu_stats", {}).get("system_cpu_usage", 0) - \
                    st.get("precpu_stats", {}).get("system_cpu_usage", 0)
        online_cpus = st.get("cpu_stats", {}).get("online_cpus", 1) or 1
        cpu_pct = (cpu_delta / sys_delta * online_cpus * 100.0) if sys_delta > 0 else 0.0
        disk_gb = 0.0
        try:
            out = c.exec_run("sh -lc \"du -s -B1 /vm 2>/dev/null | awk '{print $1}'\"").output.decode().strip()
            disk_gb = int(out or "0") / 1024**3
        except Exception:
            pass
        return {
            "cpu": cpu_pct,
            "ram_mb": usage / 1024**2,
            "ram_limit_mb": limit / 1024**2,
            "disk_gb": disk_gb
        }
    except Exception:
        return {"cpu": 0.0, "ram_mb": 0, "ram_limit_mb": vm["ram_gb"]*1024, "disk_gb": 0.0}

def vm_embed(vm, owner=None):
    running = container_running(vm)
    usage = get_usage(vm)
    expires = parse_iso(vm["expires_at"])
    remaining_hours = max(0, int((expires - now()).total_seconds() // 3600))
    remaining_days = remaining_hours // 24
    status_icon = E["online"] if running else E["offline"]
    try:
        cid = container_obj(vm).short_id
    except Exception:
        cid = "N/A"
    em = discord.Embed(
        title=f"{E['crown']} TEMPEST CLOUD • VM #{vm['id']} Control Console",
        description=(
            f"{E['star']} **Hardware slice dedicated to <@{vm['owner_id']}>**\n"
            f"{E['blackwing']} *Protected by Hardware KVM Virtualization & Anti-Mining Shields*\n\n"
            f"{E['info']} **Virtual Machine Telemetry**"
        ),
        color=0x8B5CF6 if running else 0xEF4444, timestamp=now()
    )
    em.add_field(name="", value=(
        f"{E['arrow']} **Instance Name:** `{vm_name(vm)}`\n"
        f"{E['arrow']} **Power Status:** {status_icon} `{('ONLINE' if running else 'OFFLINE')}`\n"
        f"{E['arrow']} **Container ID:** `{cid}`\n"
        f"{E['arrow']} **CPU Load:** `{vm['cpu']} vCPU` (`{usage['cpu']:.1f}%`)\n"
        f"{E['arrow']} **RAM Active:** `{vm['ram_gb']} GB` (`{usage['ram_mb']:.1f} MB`)\n"
        f"{E['arrow']} **Disk Usage:** `{vm['disk_gb']} GB` (`{usage['disk_gb']:.1f}G / {vm['disk_gb']:.1f}G` )"
    ), inline=False)
    em.add_field(name=f"{E['gear']} Network Endpoints & Lifecycle", value=(
        f"{E['arrow2']} **SSH Access:** `ssh root@{public_ip()} -p {vm['ssh_port']}`\n"
        f"{E['arrow2']} **Web VNC Port:** `{vm['vnc_port']}`\n"
        f"{E['arrow2']} **Lease Term Expires:** `{human_dt(vm['expires_at'])}`\n"
        f"{E['check']} **Ownership:** Verified\n"
        f"{E['arrow']} **Tier Role:** <@&{VM_OWNER_ROLE_ID}>\n"
        f"{E['thunder']} *Use the buttons below to open terminal, restart, or view keys.*"
    ), inline=False)
    em.set_footer(text="Nova Orchestrator • TEMPEST CLOUD")
    return em

class OwnerVMView(discord.ui.View):
    def __init__(self, vm_id, owner_id, timeout=180):
        super().__init__(timeout=timeout)
        self.vm_id = vm_id
        self.owner_id = owner_id

    async def interaction_check(self, interaction):
        vm = get_vm_by_id(self.vm_id)
        if not vm:
            await interaction.response.send_message(
                f"{E['warning']} This VM no longer exists.", ephemeral=True)
            return False
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                f"{E['warning']} **Access denied.**\nOnly the VM owner can use these buttons.",
                ephemeral=True)
            return False
        return True

    @discord.ui.button(label="SSHX", emoji="🔐", style=discord.ButtonStyle.primary)
    async def sshx(self, interaction, button):
        vm = get_vm_by_id(self.vm_id)
        if not vm:
            return await interaction.response.send_message(f"{E['warning']} VM not found.", ephemeral=True)
        await interaction.response.send_message(
            embed=embed(f"{E['loading']} SSHX • STARTING TERMINAL",
                        f"{E['star']} Preparing a live terminal for `{vm_name(vm)}`...\n\n"
                        f"{E['loading2']} Installing/checking SSHX client\n"
                        f"{E['arrow']} Opening a persistent PTY session\n"
                        f"{E['thunder']} The session will be sent to your DM.", 0x8B5CF6), ephemeral=True)
        try:
            c = container_obj(vm)
            if c.status != "running":
                c.start()
            # Install the official sshx client if necessary. Official docs provide this installer.
            install = ("sh -lc '"
                       "if ! command -v sshx >/dev/null 2>&1; then "
                       "curl -sSf https://sshx.io/get | sh; "
                       "fi; "
                       "export PATH=\"$HOME/.local/bin:$HOME/bin:/usr/local/bin:$PATH\"; "
                       "command -v sshx'" )
            r = c.exec_run(install, stdout=True, stderr=True)
            path = (r.output or b"").decode(errors="replace").strip().splitlines()[-1] if r.output else ""
            if not path or not path.startswith("/"):
                # Installer may place the binary elsewhere; resolve it from the shell.
                r2 = c.exec_run("sh -lc 'export PATH=\"$HOME/.local/bin:$HOME/bin:/usr/local/bin:$PATH\"; command -v sshx'", stdout=True, stderr=True)
                path = (r2.output or b"").decode(errors="replace").strip().splitlines()[-1] if r2.output else ""
            if not path:
                raise RuntimeError("SSHX client installation succeeded but the sshx binary could not be located.")

            log = f"/tmp/atyro-sshx-{vm['id']}.log"
            c.exec_run(f"sh -lc 'rm -f {shlex.quote(log)}; nohup script -q -e -c {shlex.quote(path)} {shlex.quote(log)} >/dev/null 2>&1 & echo $!'", stdout=True, stderr=True)
            deadline = time.time() + SSHX_TIMEOUT
            url = None
            last = ""
            while time.time() < deadline:
                await asyncio.sleep(1)
                rr = c.exec_run(f"sh -lc 'cat {shlex.quote(log)} 2>/dev/null || true'", stdout=True, stderr=True)
                last = (rr.output or b"").decode(errors="replace")
                urls = re.findall(r"https?://[^\s\"'<>]+", last)
                if urls:
                    url = urls[-1].rstrip(".,)\"'")
                    break
            if not url:
                raise RuntimeError("SSHX did not return a session URL. Output: " + (last[-1200:] or "No output"))
            try:
                await interaction.user.send(embed=embed(
                    f"{E['yes']} SSHX TERMINAL READY",
                    f"{E['star']} **Your live terminal is ready.**\n\n"
                    f"{E['arrow']} **Session:** {url}\n\n"
                    f"{E['info']} Open the link in your browser to access the VM terminal.\n"
                    f"{E['warning']} Keep this private — anyone with the link may be able to access the session.", 0x22C55E))
                await interaction.edit_original_response(embed=embed(
                    f"{E['yes']} SSHX • TERMINAL READY",
                    f"{E['green']} The SSHX terminal was created and sent to your DM.\n"
                    f"{E['thunder']} Session is running for `{vm_name(vm)}`.", 0x22C55E))
            except discord.Forbidden:
                await interaction.edit_original_response(embed=embed(
                    f"{E['warning']} SSHX • DM BLOCKED",
                    "I created the terminal, but Discord blocked my DM. Enable DMs from this server and try again.", 0xF59E0B))
        except Exception as exc:
            await interaction.edit_original_response(embed=embed(
                f"{E['warning']} SSHX • TERMINAL ERROR",
                f"{E['no']} I couldn't create the terminal.\n\n```text\n{str(exc)[:1800]}\n```", 0xEF4444))

    @discord.ui.button(label="Restart", emoji="🔄", style=discord.ButtonStyle.secondary)
    async def restart(self, interaction, button):
        vm = get_vm_by_id(self.vm_id)
        if not vm:
            return await interaction.response.send_message(f"{E['warning']} VM not found.", ephemeral=True)
        await interaction.response.send_message(
            embed=embed(f"{E['loading']} TEMPEST CLOUD • RESTARTING VM",
                        f"{E['star']} Restarting `{vm_name(vm)}`...\n\n"
                        f"{E['loading2']} Stopping VM\n{E['loading2']} Starting KVM/QEMU\n{E['thunder']} Resources and expiry remain unchanged.", 0x8B5CF6), ephemeral=True)
        try:
            c = container_obj(vm)
            c.restart(timeout=15)
            set_status(vm['id'], 'running')
            await interaction.edit_original_response(embed=embed(
                f"{E['yes']} TEMPEST CLOUD • VM ONLINE",
                f"{E['green']} `{vm_name(vm)}` restarted successfully.\n{E['online']} Power status: `ONLINE`", 0x22C55E))
        except Exception as exc:
            set_status(vm['id'], 'error')
            await interaction.edit_original_response(embed=embed(
                f"{E['warning']} RESTART FAILED", f"```text\n{str(exc)[:1500]}\n```", 0xEF4444))

    @discord.ui.button(label="Reinstall OS", emoji="♻️", style=discord.ButtonStyle.danger)
    async def reinstall(self, interaction, button):
        await interaction.response.send_message(
            f"{E['warning']} **Reinstall Ubuntu?**\n\n"
            f"This will erase the current VM OS/data on its `/vm` volume.\n"
            f"RAM, CPU, disk size and **expiry date will remain unchanged**.",
            view=ConfirmReinstallView(self.vm_id, self.owner_id),
            ephemeral=True)

    @discord.ui.button(label="Refresh", emoji="🔄", style=discord.ButtonStyle.secondary)
    async def refresh(self, interaction, button):
        vm = get_vm_by_id(self.vm_id)
        if not vm:
            return await interaction.response.send_message(
                f"{E['warning']} VM not found.", ephemeral=True)
        await interaction.response.edit_message(embed=vm_embed(vm), view=self)

class ConfirmReinstallView(discord.ui.View):
    def __init__(self, vm_id, owner_id):
        super().__init__(timeout=60)
        self.vm_id = vm_id
        self.owner_id = owner_id

    @discord.ui.button(label="Confirm Reinstall", style=discord.ButtonStyle.danger, emoji="⚠️")
    async def yes(self, interaction, button):
        if interaction.user.id != self.owner_id:
            return await interaction.response.send_message(
                f"{E['warning']} Access denied.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        vm = get_vm_by_id(self.vm_id)
        if not vm:
            return await interaction.followup.send(f"{E['warning']} VM not found.", ephemeral=True)
        try:
            set_status(vm["id"], "reinstalling")
            try:
                c = container_obj(vm)
                c.remove(force=True)
            except NotFound:
                pass
            # Fresh volume = clean OS/data while preserving DB expiry/resources.
            try:
                docker_client.volumes.get(vm["volume"]).remove(force=True)
            except NotFound:
                pass
            docker_client.volumes.create(name=vm["volume"], labels={"atyro.vm_id": str(vm["id"])})
            make_container(vm)
            set_status(vm["id"], "running")
            await interaction.followup.send(
                f"{E['yes']} **OS reinstalled successfully.**\n"
                f"{E['arrow']} Your expiry date was not changed.",
                ephemeral=True)
        except Exception as exc:
            set_status(vm["id"], "error")
            await interaction.followup.send(
                f"{E['warning']} Reinstall failed:\n`{str(exc)[:1500]}`", ephemeral=True)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def no(self, interaction, button):
        await interaction.response.edit_message(content=f"{E['green']} Reinstall cancelled.", view=None)

# ---------------- Commands ----------------

@bot.command(name="vm")
@admin_only()
async def create_vm(ctx, ram: int, cpu: int, disk: int, member: discord.Member):
    if get_vm(member.id):
        return await ctx.send(embed=embed(
            f"{E['warning']} VM ALREADY EXISTS",
            f"{member.mention} already owns a VM. Use `{PREFIX}manage {member.mention}`.", 0xF59E0B))
    if ram < 1 or ram > MAX_RAM_GB or cpu < 1 or cpu > MAX_CPU or disk < 10 or disk > MAX_DISK_GB:
        return await ctx.send(embed=embed(
            f"{E['warning']} INVALID VM SIZE",
            f"Allowed: RAM **1-{MAX_RAM_GB} GB**, CPU **1-{MAX_CPU}**, Disk **10-{MAX_DISK_GB} GB**.", 0xEF4444))
    ssh, vnc = allocate_ports()
    suffix = uuid.uuid4().hex[:8]
    # Temporary container name is replaced after the DB autoincrement VM number is known.
    container = f"atyro-vm-pending-{suffix}"
    volume = f"atyro-vm-{suffix}-data"
    created = now(); expires = created + timedelta(days=DEFAULT_DAYS)
    add_vm(member.id, container, volume, ram, cpu, disk, ssh, vnc, iso(created), iso(expires))
    vm = get_vm(member.id)
    desired_name = f"atyro-vm-{member.id}-{vm['id']}"
    db.execute("UPDATE vms SET container=? WHERE id=?", (desired_name, vm["id"])); db.commit()
    vm = get_vm(member.id)

    msg = await ctx.send(embed=embed(
        f"{E['loading']} TEMPEST CLOUD • PROVISIONING VM",
        f"{E['star']} **Preparing dedicated KVM virtualization**\n\n"
        f"{E['arrow']} **Owner:** {member.mention}\n"
        f"{E['arrow']} **Instance:** `{desired_name}`\n"
        f"{E['arrow']} **CPU:** `{cpu} vCPU`\n"
        f"{E['arrow']} **RAM:** `{ram} GB`\n"
        f"{E['arrow']} **Disk:** `{disk} GB NVMe`\n\n"
        f"{E['loading2']} Creating persistent storage\n"
        f"{E['loading2']} Starting hardware KVM virtualization\n"
        f"{E['loading2']} Booting Ubuntu 24.04 image\n"
        f"{E['thunder']} Lease: **{DEFAULT_DAYS} days**", 0x8B5CF6))
    try:
        docker_client.volumes.create(name=volume, labels={"atyro.vm_id": str(vm["id"])})
        await msg.edit(embed=embed(
            f"{E['loading']} TEMPEST CLOUD • STARTING KVM",
            f"{E['star']} **VM #{vm['id']}** is being started.\n\n"
            f"{E['arrow']} Instance: `{desired_name}`\n"
            f"{E['online']} Virtualization: `KVM / QEMU`\n"
            f"{E['arrow2']} SSH: `{ssh}` • VNC: `{vnc}`\n"
            f"{E['loading2']} Launching privileged Atyro Ubuntu 24.04 container...", 0x8B5CF6))
        make_container(vm)
        set_status(vm["id"], "running")
        vm = get_vm(member.id)
        await grant_role(member, VM_OWNER_ROLE_ID)
        await msg.edit(embed=vm_embed(vm))
        try:
            await member.send(embed=embed(
                f"{E['yes']} TEMPEST CLOUD • VM PROVISIONED",
                f"{E['star']} Your dedicated KVM VM is online.\n\n"
                f"{E['arrow']} Instance: `{vm_name(vm)}`\n"
                f"{E['arrow']} Resources: `{cpu} vCPU` • `{ram} GB RAM` • `{disk} GB NVMe`\n"
                f"{E['arrow2']} SSH: `ssh root@{public_ip()} -p {ssh}`\n"
                f"{E['arrow2']} VNC: `{vnc}`\n"
                f"{E['coin']} Expires: `{human_dt(vm['expires_at'])}`\n\n"
                f"{E['thunder']} Use `{PREFIX}manage` to open your VM console.", 0x22C55E))
        except discord.Forbidden:
            pass
    except Exception as exc:
        try:
            docker_client.containers.get(desired_name).remove(force=True)
        except Exception:
            try: docker_client.containers.get(container).remove(force=True)
            except Exception: pass
        try: docker_client.volumes.get(volume).remove(force=True)
        except Exception: pass
        delete_db_vm(vm["id"])
        await msg.edit(embed=embed(
            f"{E['warning']} TEMPEST CLOUD • PROVISIONING FAILED",
            f"{E['no']} The VM could not be created.\n\n```text\n{str(exc)[:2200]}\n```", 0xEF4444))
        try:
            await member.send(embed=embed(
                f"{E['warning']} VM CREATION FAILED",
                f"Your VM could not be provisioned.\n\n```text\n{str(exc)[:1200]}\n```", 0xEF4444))
        except Exception:
            pass

@bot.command(name="manage")
async def manage(ctx, member: discord.Member = None):
    target = member or ctx.author
    vm = get_vm(target.id)
    if not vm:
        return await ctx.send(embed=embed(
            f"{E['warning']} No VM Found",
            f"{target.mention} does not have a VM.", 0xF59E0B))
    if not await owner_or_admin(ctx, target.id):
        return await ctx.send(embed=embed(
            f"{E['warning']} Access Denied",
            "Only the VM owner or a bot admin can manage this VM.", 0xEF4444))
    await ctx.send(embed=vm_embed(vm), view=OwnerVMView(vm["id"], vm["owner_id"]))

@bot.command(name="renew")
@admin_only()
async def renew(ctx, member: discord.Member):
    vm = get_vm(member.id)
    if not vm:
        return await ctx.send(embed=embed(f"{E['warning']} No VM", "That user has no VM.", 0xEF4444))
    current = max(now(), parse_iso(vm["expires_at"]))
    new_expiry = current + timedelta(days=DEFAULT_DAYS)
    db.execute("UPDATE vms SET expires_at=? WHERE id=?", (iso(new_expiry), vm["id"]))
    db.commit()
    try:
        c = container_obj(vm)
        c.start()
        set_status(vm["id"], "running")
    except Exception:
        pass
    await ctx.send(embed=embed(
        f"{E['yes']} VM RENEWED",
        f"{member.mention}'s VM was renewed for **{DEFAULT_DAYS} days**.\n"
        f"{E['coin']} New expiry: **{human_dt(iso(new_expiry))}**\n"
        f"{E['arrow']} Resources were unchanged.",
        0x22C55E))

@bot.command(name="delete")
@admin_only()
async def delete_vm(ctx, member: discord.Member):
    vm = get_vm(member.id)
    if not vm:
        return await ctx.send(embed=embed(f"{E['warning']} No VM", "That user has no VM.", 0xEF4444))
    await ctx.send(
        embed=embed(f"{E['warning']} Confirm VM Deletion",
                    f"This permanently deletes **VM-{vm['id']:05d}** and its `/vm` volume.\n"
                    f"Owner: {member.mention}\n\nThis cannot be undone.", 0xEF4444),
        view=ConfirmDeleteView(vm["id"], ctx.author.id)
    )

class ConfirmDeleteView(discord.ui.View):
    def __init__(self, vm_id, requester_id):
        super().__init__(timeout=60)
        self.vm_id = vm_id
        self.requester_id = requester_id

    @discord.ui.button(label="Delete VM", style=discord.ButtonStyle.danger, emoji="🗑️")
    async def yes(self, interaction, button):
        if interaction.user.id != self.requester_id and not is_admin(interaction.user):
            return await interaction.response.send_message(f"{E['warning']} Access denied.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        vm = get_vm_by_id(self.vm_id)
        if not vm:
            return await interaction.followup.send(f"{E['warning']} VM already deleted.", ephemeral=True)
        try:
            try: container_obj(vm).remove(force=True)
            except NotFound: pass
            try: docker_client.volumes.get(vm["volume"]).remove(force=True)
            except NotFound: pass
            delete_db_vm(vm["id"])
            owner = interaction.guild.get_member(vm["owner_id"]) if interaction.guild else None
            if owner:
                await remove_role(owner, VM_OWNER_ROLE_ID)
                try:
                    await owner.send(embed=embed(
                        f"{E['down']} TEMPEST CLOUD • VM TERMINATED",
                        f"{E['green']} **Member Allocation Wiped**\n\n"
                        f"{E['yes']} **All 1 VM(s) owned by {owner.mention} have been terminated.**\n\n"
                        f"{E['arrow']} **Storage:** Volumes unmounted & removed\n"
                        f"{E['down']} Client role <@&{VM_OWNER_ROLE_ID}> was stripped.", 0xEF4444))
                except discord.Forbidden:
                    pass
            await interaction.followup.send(
                embed=embed(
                    f"{E['green']} MEMBER ALLOCATION WIPED",
                    f"{E['yes']} **All 1 VM(s) owned by <@{vm['owner_id']}> have been terminated.**\n\n"
                    f"{E['arrow']} **Storage:** Volumes unmounted & removed\n"
                    f"{E['down']} Client role <@&{VM_OWNER_ROLE_ID}> was stripped.", 0x22C55E), ephemeral=True)
        except Exception as exc:
            await interaction.followup.send(f"{E['warning']} Delete failed: `{exc}`", ephemeral=True)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def no(self, interaction, button):
        await interaction.response.edit_message(content=f"{E['green']} Deletion cancelled.", embed=None, view=None)

@bot.command(name="setadmin", aliases=["adminset"])
@admin_only()
async def setadmin(ctx, member: discord.Member):
    db.execute("INSERT OR IGNORE INTO admins(user_id,added_at) VALUES(?,?)", (member.id, iso(now())))
    db.commit()
    role_ok = await grant_role(member, BOT_ADMIN_ROLE_ID)
    role_note = "" if role_ok else f"\n{E['warning']} Admin role could not be assigned; check the bot's Manage Roles permission and role hierarchy."
    await ctx.send(embed=embed(
        f"{E['yes']} ADMIN ADDED",
        f"{member.mention} can now use Atyro admin commands.\n{E['star']} Admin role: <@&{BOT_ADMIN_ROLE_ID}>{role_note}", 0x22C55E))

@bot.command(name="removeadmin")
@admin_only()
async def removeadmin(ctx, member: discord.Member):
    if member.id == BOT_OWNER_ID:
        return await ctx.send(embed=embed(f"{E['warning']} Protected Admin", "The main bot administrator cannot be removed.", 0xF59E0B))
    if member.id == ctx.author.id and ctx.guild.owner_id != ctx.author.id:
        return await ctx.send(embed=embed(f"{E['warning']} Protected", "You cannot remove your own admin access.", 0xF59E0B))
    db.execute("DELETE FROM admins WHERE user_id=?", (member.id,))
    db.commit()
    await remove_role(member, BOT_ADMIN_ROLE_ID)
    await ctx.send(embed=embed(
        f"{E['yes']} ADMIN REMOVED",
        f"{member.mention} no longer has Atyro admin command access.\n{E['arrow']} Admin role removed: <@&{BOT_ADMIN_ROLE_ID}>", 0x22C55E))

@bot.command(name="vminfo")
@admin_only()
async def vminfo(ctx):
    rows = db_all("SELECT * FROM vms ORDER BY id")
    if not rows:
        return await ctx.send(embed=embed(f"{E['info']} TEMPEST NODE • GLOBAL VM REGISTRY", "No VMs are currently provisioned.", 0x64748B))
    lines = [f"{E['star']} **Active Provisioned Slices:** `{len(rows)}`", ""]
    for vm in rows:
        status = f"{E['online']} ONLINE" if container_running(vm) else f"{E['offline']} OFFLINE"
        lines.append(
            f"{status} **VM #{vm['id']}:** `{vm_name(vm)}`\n"
            f"{E['arrow']} **Owner:** <@{vm['owner_id']}>\n"
            f"{E['arrow']} **Hardware:** `{vm['cpu']} vCPU` | `{vm['ram_gb']}G RAM` | `{vm['disk_gb']}G NVMe`\n"
            f"{E['arrow2']} **Ports:** `SSH {vm['ssh_port']}` | `VNC {vm['vnc_port']}`\n"
            f"{E['arrow2']} **Expires:** `{human_dt(vm['expires_at'])}`\n"
        )
    text = "\n".join(lines)
    if len(text) > 3900: text = text[:3800] + "\n…"
    em = embed(f"{E['crown']} TEMPEST NODE • Global Virtual Machine Registry", text, 0x8B5CF6)
    em.set_footer(text="Nova Orchestrator • TEMPEST CLOUD")
    await ctx.send(embed=em)

@bot.command(name="help")
async def help_cmd(ctx):
    em = embed(f"{E['bot']} ATYRO VM MANAGER",
               f"{E['star']} Professional KVM VM management through Discord.")
    em.add_field(name=f"{E['crown']} Admin Commands",
                 value=f"`{PREFIX}vm <ram> <cpu> <disk> @user`\n"
                       f"`{PREFIX}renew @user`\n`{PREFIX}delete @user`\n"
                       f"`{PREFIX}manage @user`\n`{PREFIX}vminfo`\n"
                       f"`{PREFIX}setadmin @user`\n`{PREFIX}removeadmin @user`", inline=False)
    em.add_field(name=f"{E['profile']} Owner",
                 value=f"`{PREFIX}manage` — view your VM and use SSHX/Reinstall/Refresh.",
                 inline=False)
    await ctx.send(embed=em)

# ---------------- Expiry monitor ----------------

@tasks.loop(minutes=10)
async def expiry_monitor():
    rows = db_all("SELECT * FROM vms")
    for vm in rows:
        try:
            exp = parse_iso(vm["expires_at"])
            remaining = (exp - now()).total_seconds()
            if remaining <= 0:
                try: container_obj(vm).stop(timeout=10)
                except Exception: pass
                set_status(vm["id"], "expired")
                user = bot.get_user(vm["owner_id"])
                if user:
                    try:
                        await user.send(embed=embed(
                            f"{E['down']} TEMPEST CLOUD • VM EXPIRED",
                            f"{E['warning']} Your VM `{vm_name(vm)}` has expired and has been stopped.\n\n"
                            f"{E['coin']} Expired: `{human_dt(vm['expires_at'])}`\n"
                            f"{E['arrow']} Contact an administrator to renew it.", 0xEF4444))
                    except Exception: pass
                continue
            days = int(remaining // 86400)
            if days in (7, 3, 1):
                already = db_one("SELECT 1 FROM expiry_notices WHERE vm_id=? AND days=?", (vm["id"], days))
                if not already:
                    user = bot.get_user(vm["owner_id"])
                    if user:
                        try:
                            await user.send(embed=embed(
                                f"{E['warning']} TEMPEST CLOUD • VM EXPIRING",
                                f"{E['star']} Your VM `{vm_name(vm)}` expires in **{days} day(s)**.\n\n"
                                f"{E['coin']} Expiry: `{human_dt(vm['expires_at'])}`\n"
                                f"{E['thunder']} Ask an administrator to renew your 28-day lease.", 0xF59E0B))
                        except Exception: pass
                    db.execute("INSERT OR IGNORE INTO expiry_notices(vm_id,days,sent_at) VALUES(?,?,?)", (vm["id"], days, iso(now())))
                    db.commit()
        except Exception:
            continue

@expiry_monitor.before_loop
async def before_expiry():
    await bot.wait_until_ready()

@bot.event
async def on_ready():
    if not expiry_monitor.is_running():
        expiry_monitor.start()
    print(f"Logged in as {bot.user} | Docker image: {IMAGE}")

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CheckFailure):
        return await ctx.send(embed=embed(
            f"{E['warning']} Access Denied",
            "You do not have permission to use this command.", 0xEF4444))
    if isinstance(error, commands.MissingRequiredArgument):
        return await ctx.send(embed=embed(
            f"{E['info']} Missing Information",
            f"Usage: `{PREFIX}{ctx.command.name} {ctx.command.signature}`", 0xF59E0B))
    if isinstance(error, commands.BadArgument):
        return await ctx.send(embed=embed(
            f"{E['warning']} Invalid Input",
            "Check the command format and mention a valid Discord user.", 0xF59E0B))
    print("Command error:", repr(error))
    await ctx.send(embed=embed(
        f"{E['warning']} Something Went Wrong",
        f"`{str(error)[:1500]}`", 0xEF4444))

if not TOKEN:
    raise SystemExit("DISCORD_TOKEN is missing. Copy .env.example to .env and add your bot token.")

bot.run(TOKEN)
