from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import secrets
import shlex
import string
import subprocess
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import discord
from discord.ext import commands, tasks

# ============================================================
# ATYRO VM DISCORD BOT - FIXED GUEST SSHX EDITION
# ============================================================
# The important SSHX fix is that SSHX no longer opens the
# Docker wrapper shell. It starts an SSH client to QEMU's guest
# SSH service on 127.0.0.1:2222 inside the wrapper.
# ============================================================

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("atyro-bot")

BASE = Path(__file__).resolve().parent
DATA_FILE = BASE / "vms.json"
ADMINS_FILE = BASE / "admins.json"

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
BOT_OWNER_ID = int(os.getenv("BOT_OWNER_ID", "1447083500720230401"))
VM_OWNER_ROLE_ID = int(os.getenv("VM_OWNER_ROLE_ID", "1545501965562159116"))
BOT_ADMIN_ROLE_ID = int(os.getenv("BOT_ADMIN_ROLE_ID", "1546053390528811120"))

IMAGE = os.getenv("ATYRO_IMAGE", "hopingboyz/atyro-ubuntu24")
PREFIX = "!"
LIFETIME_DAYS = 28
SSH_HOST_START = int(os.getenv("SSH_HOST_START", "2026"))
VNC_HOST_START = int(os.getenv("VNC_HOST_START", "6080"))

# Custom emoji IDs supplied for this bot.
E_YES = "<a:yes:1519555946312106024>"
E_ARROW = "<a:arrow:1519555946312106025>"
E_ARROW2 = "<a:arrow:1519556677173511156>"  # safe fallback if unavailable
E_STAR = "<a:star:1519557024801751051>"
E_ONLINE = "<a:Online:1519557436854370334>"
E_OFFLINE = "<a:offline:1519557662977822941>"
E_LOADING = "<a:Loading:1519558138209112155>"
E_THUNDER = "<a:thunder:1519558414353698927>"
E_BOT = "<:bot_tag:1519559016013889647>"
E_WARNING = "<a:Warning:1519588395620499648>"
E_GREEN = "<a:greencheck:1519588992767496193>"
E_LIGHTNING = "<a:65023lightning:1519762787579072593>"
E_NO = "<a:vote_no:1519763086570164246>"
E_CHECK = "<a:vote_yes:1519763256992993422>"
E_CROWN = "<a:King_crown:1519766073560403990>"
E_COIN = "<a:coin:1519767909847535750>"
E_PROFILE = "<:profil:1520088044970180638>"
E_LOAD2 = "<a:loading_icon:1520088258027982858>"
E_WAVES = "<a:waves:1520088703811326122>"
E_DOWN = "<a:DOWN:1520088811399413850>"
E_FIRE = "<a:fire:1520089278225453186>"
E_GEAR = "<a:PurpleGear:1545024403216269395>"
E_CART = "<a:shopping_cart:1545024782016192612>"
E_MONEY = "<:money:1545027262229774389>"
E_WING = "<a:blackWing1:1545024935016144947>"
E_INFO = "<:Information:1545028101501747230>"
E_MOD = "<:ModeratorRoleIcon:1545029625405505586>"
E_GG = "<a:GG:1519587770425933824>"

COLOR = 0x8B5CF6
SUCCESS = 0x22C55E
ERROR = 0xEF4444
WARNING = 0xF59E0B
INFO = 0x38BDF8
DARK = 0x111827

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)


def load_json(path: Path, default):
    try:
        return json.loads(path.read_text())
    except Exception:
        return default


def save_json(path: Path, data):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2))
    tmp.replace(path)


vms: dict[str, dict] = load_json(DATA_FILE, {})
admins: set[str] = set(str(x) for x in load_json(ADMINS_FILE, []))
admins.add(str(BOT_OWNER_ID))


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat()


def parse_dt(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def is_admin_id(uid: int | str) -> bool:
    return str(uid) == str(BOT_OWNER_ID) or str(uid) in admins


def is_admin_member(member: discord.Member) -> bool:
    return is_admin_id(member.id) or any(r.id == BOT_ADMIN_ROLE_ID for r in member.roles)


def save_all():
    save_json(DATA_FILE, vms)
    save_json(ADMINS_FILE, sorted(admins))


def embed(title: str, description: str = "", color: int = COLOR) -> discord.Embed:
    e = discord.Embed(title=title, description=description, color=color, timestamp=now_utc())
    e.set_footer(text="ATYRO CLOUD • Ubuntu VM Infrastructure")
    return e


def success(title, description=""):
    return embed(f"{E_GREEN} {title}", description, SUCCESS)


def error(title, description=""):
    return embed(f"{E_WARNING} {title}", description, ERROR)


def info(title, description=""):
    return embed(f"{E_INFO} {title}", description, INFO)


def warn(title, description=""):
    return embed(f"{E_WARNING} {title}", description, WARNING)


async def run_cmd(args: list[str], timeout=120, check=True) -> tuple[str, str, int]:
    proc = await asyncio.create_subprocess_exec(
        *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        raise RuntimeError(f"Command timed out: {' '.join(args)}")
    out_s, err_s = out.decode(errors="replace"), err.decode(errors="replace")
    if check and proc.returncode != 0:
        raise RuntimeError(err_s.strip() or out_s.strip() or f"exit {proc.returncode}")
    return out_s.strip(), err_s.strip(), proc.returncode


async def docker(*args, timeout=120, check=True):
    return await run_cmd(["docker", *args], timeout=timeout, check=check)


async def host_port_free(port: int) -> bool:
    out, _, _ = await docker("ps", "--format", "{{.Ports}}", check=False)
    return not any(re.search(rf"(?:^|[^0-9]):{port}->", line) for line in out.splitlines())


async def allocate_ports() -> tuple[int, int]:
    used = set()
    out, _, _ = await docker("ps", "--format", "{{.Ports}}", check=False)
    for m in re.finditer(r":(\d+)->", out):
        used.add(int(m.group(1)))
    ssh = SSH_HOST_START
    while ssh in used or not await host_port_free(ssh):
        ssh += 1
    vnc = VNC_HOST_START
    while vnc in used or not await host_port_free(vnc):
        vnc += 1
    return ssh, vnc


def container_name(uid: int, vm_id: str) -> str:
    return f"atyro-vm-{uid}-{vm_id}"


def random_password(length=18):
    chars = string.ascii_letters + string.digits + "!@#$%"
    return "".join(secrets.choice(chars) for _ in range(length))


async def vm_exists(name: str) -> bool:
    _, _, rc = await docker("inspect", name, check=False)
    return rc == 0


async def vm_status(rec: dict) -> str:
    name = rec["container"]
    out, _, rc = await docker("inspect", "--format", "{{.State.Status}}", name, check=False)
    return out.strip() if rc == 0 else "missing"


async def ensure_guest_sshx_dependencies(name: str):
    """Install ssh client in the wrapper only when needed.

    Atyro's wrapper can be Alpine-based, while the actual guest is Ubuntu.
    SSHX itself is already known to work in the wrapper. We only need an SSH
    client so the SSHX shell can enter QEMU guest port 2222.
    """
    cmd = r'''set -eu
if command -v ssh >/dev/null 2>&1; then exit 0; fi
if command -v apk >/dev/null 2>&1; then
    apk add --no-cache openssh-client >/dev/null 2>&1 || apk add --no-cache openssh >/dev/null 2>&1
elif command -v apt-get >/dev/null 2>&1; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -qq
    apt-get install -y -qq openssh-client >/dev/null
elif command -v dnf >/dev/null 2>&1; then
    dnf install -y openssh-clients >/dev/null
else
    echo 'No supported package manager is available to install ssh client' >&2
    exit 45
fi
command -v ssh >/dev/null 2>&1
'''
    await docker("exec", name, "sh", "-lc", cmd, timeout=120)


async def get_guest_sshx(rec: dict) -> str:
    """Return SSHX URL whose terminal is the Ubuntu QEMU guest, not wrapper."""
    name = rec["container"]
    if await vm_status(rec) != "running":
        await docker("start", name, timeout=45)
        await asyncio.sleep(3)

    await ensure_guest_sshx_dependencies(name)

    # SSHX is executed inside the wrapper. The wrapper's QEMU user-mode
    # networking exposes the Ubuntu guest SSH service at 127.0.0.1:2222.
    script = r'''set -eu
SSHX_BIN="$(command -v sshx || true)"
if [ -z "$SSHX_BIN" ]; then
  curl -sSf https://sshx.io/get | sh >/dev/null
  SSHX_BIN="$(command -v sshx || true)"
fi
[ -n "$SSHX_BIN" ] || exit 44

LOG=/tmp/atyro-sshx.log
rm -f "$LOG"
nohup "$SSHX_BIN" --quiet --shell 'exec ssh -tt -p 2222 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null root@127.0.0.1' >"$LOG" 2>&1 < /dev/null &
PID=$!

for i in $(seq 1 40); do
  URL=$(grep -Eo 'https://sshx\.io/s/[^[:space:]<>"'"'"']+' "$LOG" 2>/dev/null | head -n1 || true)
  if [ -n "$URL" ]; then
    printf '%s\n' "$URL"
    exit 0
  fi
  if ! kill -0 "$PID" 2>/dev/null; then
    break
  fi
  sleep 1
done
cat "$LOG" 2>/dev/null || true
exit 46
'''
    out, err, rc = await docker("exec", name, "sh", "-lc", script, timeout=60, check=False)
    text = "\n".join(x for x in (out, err) if x)
    m = re.search(r"https://sshx\.io/s/[^\s<>\"']+", text)
    if not m:
        raise RuntimeError(f"SSHX guest session failed (exit {rc}).\n{text[-1800:] or 'No output'}")
    return m.group(0).rstrip(".,;)")


async def create_vm(rec: dict):
    name = rec["container"]
    ram = int(rec["ram_gb"]) * 1024
    cpu = int(rec["cpu"])
    disk = int(rec["disk_gb"])
    ssh_port = int(rec["ssh_port"])
    vnc_port = int(rec["vnc_port"])
    root_pass = rec["root_password"]

    if await vm_exists(name):
        await docker("rm", "-f", name, check=False)

    # The Atyro image's own entrypoint/QEMU process handles the Ubuntu guest.
    # We preserve its required /dev/kvm and /vm persistent volume behavior.
    args = [
        "run", "-d",
        "--name", name,
        "--privileged",
        "--device", "/dev/kvm",
        "-p", f"{vnc_port}:6080",
        "-p", f"{ssh_port}:2222",
        "-e", f"RAM={ram}",
        "-e", f"CPU={cpu}",
        "-e", f"DISK={disk}",
        "-e", "VNC_PASS=admin",
        "-e", f"ROOT_PASS={root_pass}",
        "-v", f"{name}-data:/vm",
        "--restart", "unless-stopped",
        IMAGE,
    ]
    await docker(*args, timeout=180)
    await asyncio.sleep(6)

    # If QEMU is still booting, don't fail the VM creation. SSHX/renew/manage
    # will retry when the guest is ready.


async def delete_vm_record(rec: dict):
    await docker("rm", "-f", rec["container"], check=False)
    await docker("volume", "rm", f"{rec['container']}-data", check=False)


async def grant_vm_role(member: discord.Member):
    if not member.guild:
        return
    role = member.guild.get_role(VM_OWNER_ROLE_ID)
    if role:
        try:
            await member.add_roles(role, reason="ATYRO VM owner")
        except discord.HTTPException:
            pass


async def remove_vm_role_if_needed(member: discord.Member):
    if not member.guild:
        return
    if any(str(r.get("owner")) == str(member.id) for r in vms.values()):
        return
    role = member.guild.get_role(VM_OWNER_ROLE_ID)
    if role:
        try:
            await member.remove_roles(role, reason="No ATYRO VM remaining")
        except discord.HTTPException:
            pass


async def owner_record(user_id: int) -> Optional[dict]:
    records = [r for r in vms.values() if str(r.get("owner")) == str(user_id)]
    records.sort(key=lambda r: r.get("created_at", ""))
    return records[-1] if records else None


async def resolve_user_record(user_id: int) -> Optional[dict]:
    return await owner_record(user_id)


class ManageView(discord.ui.View):
    def __init__(self, viewer_id: int, rec: dict, owner_id: int):
        super().__init__(timeout=600)
        self.viewer_id = viewer_id
        self.owner_id = owner_id
        self.rec = rec
        owner_only = viewer_id == owner_id
        self.add_item(self._button("SSHX", discord.ButtonStyle.primary, "sshx", 0, enabled=owner_only))
        self.add_item(self._button("Reinstall OS", discord.ButtonStyle.danger, "reinstall", 0, enabled=owner_only))
        self.add_item(self._button("Restart", discord.ButtonStyle.secondary, "restart", 0, enabled=owner_only))
        self.add_item(self._button("Refresh", discord.ButtonStyle.success, "refresh", 0, enabled=True))

    def _button(self, label, style, action, row, enabled=True):
        b = discord.ui.Button(label=label, style=style, row=row)
        b.disabled = not enabled
        b.callback = self.callback_for(action)
        return b

    def callback_for(self, action):
        async def cb(interaction: discord.Interaction):
            if interaction.user.id != self.viewer_id:
                await interaction.response.send_message(
                    embed=warn("Access Denied", f"{E_NO} This management panel belongs to another user."), ephemeral=True
                )
                return
            if action in {"sshx", "reinstall", "restart"} and interaction.user.id != self.owner_id and not is_admin_id(interaction.user.id):
                await interaction.response.send_message(embed=warn("Owner Only", "Only the VM owner can use this action."), ephemeral=True)
                return
            await handle_manage_action(interaction, self.rec, action)
        return cb


async def management_embed(rec: dict) -> discord.Embed:
    status = await vm_status(rec)
    expires = parse_dt(rec["expires_at"])
    left = expires - now_utc()
    days = max(0, left.days)
    e = embed(f"{E_GEAR} ATYRO CLOUD • VM CONTROL", f"`{rec['container']}`", COLOR)
    e.add_field(name="Owner", value=f"<@{rec['owner']}>`,".replace("`", ""), inline=True)
    e.add_field(name="Status", value=f"{E_ONLINE if status == 'running' else E_OFFLINE} `{status.upper()}`", inline=True)
    e.add_field(name="Expiry", value=f"`{days}d` • `{expires:%Y-%m-%d}`", inline=True)
    e.add_field(name="Resources", value=f"🧠 `{rec['ram_gb']} GB RAM`\n⚙️ `{rec['cpu']} CPU`\n💾 `{rec['disk_gb']} GB Disk`", inline=True)
    e.add_field(name="Guest SSH", value=f"`127.0.0.1:2222` inside wrapper\nPublic SSH: `{rec['ssh_port']}`", inline=True)
    e.add_field(name="KVM", value=f"`/dev/kvm` → `{IMAGE}`", inline=True)
    e.add_field(name="Controls", value="Use the buttons below. SSHX opens the **Ubuntu guest**, not the Docker wrapper.", inline=False)
    return e


async def handle_manage_action(interaction: discord.Interaction, rec: dict, action: str):
    name = rec["container"]
    if action == "refresh":
        await interaction.response.edit_message(embed=await management_embed(rec), view=ManageView(interaction.user.id, rec, int(rec["owner"])))
        return
    await interaction.response.defer(ephemeral=True)
    try:
        if action == "restart":
            await docker("restart", name, timeout=60)
            await interaction.followup.send(embed=success("VM Restarted", f"`{name}` is restarting."), ephemeral=True)
        elif action == "sshx":
            await interaction.followup.send(embed=info("SSHX", f"{E_LOADING} Creating a browser terminal connected to Ubuntu guest…"), ephemeral=True)
            url = await get_guest_sshx(rec)
            e = success("Ubuntu SSHX Ready", "This session opens the **real Ubuntu VM guest**.")
            e.add_field(name="Browser Terminal", value=f"[Open SSHX]({url})", inline=False)
            e.add_field(name="Important", value="If prompted, enter the VM root password. You should see Ubuntu and `apt` will work.", inline=False)
            try:
                await interaction.user.send(embed=e)
                await interaction.followup.send(embed=success("SSHX Sent", "I sent the Ubuntu guest terminal to your DMs."), ephemeral=True)
            except discord.Forbidden:
                await interaction.followup.send(embed=e, ephemeral=True)
        elif action == "reinstall":
            old = dict(rec)
            await delete_vm_record(rec)
            rec["root_password"] = random_password()
            await create_vm(rec)
            rec["created_at"] = iso(now_utc())
            save_all()
            await interaction.followup.send(embed=success("OS Reinstalled", f"`{name}` was recreated with the same RAM/CPU/disk and expiry.\nRoot password changed to `{rec['root_password']}`."), ephemeral=True)
        else:
            await interaction.followup.send(embed=error("Unknown Action"), ephemeral=True)
    except Exception as exc:
        log.exception("manage action failed")
        await interaction.followup.send(embed=error("Action Failed", f"```text\n{str(exc)[:1800]}\n```"), ephemeral=True)


@bot.event
async def on_ready():
    log.info("Logged in as %s", bot.user)
    expiry_loop.start()


@bot.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return
    if message.content.startswith(PREFIX) and is_admin_id(message.author.id):
        try:
            await message.add_reaction(E_GG)
        except discord.HTTPException:
            pass
    await bot.process_commands(message)


@bot.command(name="vm")
@commands.guild_only()
async def create_vm_cmd(ctx: commands.Context, ram: int, cpu: int, disk: int, user: discord.Member):
    if not is_admin_member(ctx.author):
        await ctx.send(embed=error("Access Denied", "Only bot admins can create VMs."))
        return
    if ram <= 0 or cpu <= 0 or disk <= 0:
        await ctx.send(embed=error("Invalid Resources", "RAM, CPU and disk must be positive numbers."))
        return
    existing = await owner_record(user.id)
    if existing:
        await ctx.send(embed=warn("VM Already Exists", f"{user.mention} already owns `{existing['container']}`."))
        return
    ssh_port, vnc_port = await allocate_ports()
    vm_id = uuid.uuid4().hex[:8]
    rec = {
        "id": vm_id,
        "owner": str(user.id),
        "container": container_name(user.id, vm_id),
        "ram_gb": ram,
        "cpu": cpu,
        "disk_gb": disk,
        "ssh_port": ssh_port,
        "vnc_port": vnc_port,
        "root_password": random_password(),
        "created_at": iso(now_utc()),
        "expires_at": iso(now_utc() + timedelta(days=LIFETIME_DAYS)),
    }
    msg = await ctx.send(embed=info("Creating VM", f"{E_LOADING} Deploying Ubuntu 24.04 VM for {user.mention}…"))
    try:
        await create_vm(rec)
        vms[vm_id] = rec
        save_all()
        await grant_vm_role(user)
        e = success("VM Created", f"{user.mention} your Ubuntu VM is ready.")
        e.add_field(name="VM", value=f"`{rec['container']}`", inline=False)
        e.add_field(name="Resources", value=f"`{ram}GB RAM` • `{cpu} CPU` • `{disk}GB Disk`", inline=True)
        e.add_field(name="SSH", value=f"`ssh -p {ssh_port} root@YOUR-VPS-IP`", inline=True)
        e.add_field(name="Expiry", value=f"`{LIFETIME_DAYS} days`", inline=True)
        try:
            await user.send(embed=e)
        except discord.Forbidden:
            pass
        await msg.edit(embed=e)
    except Exception as exc:
        await msg.edit(embed=error("VM Creation Failed", f"```text\n{str(exc)[:1800]}\n```"))


@bot.command(name="manage")
async def manage_cmd(ctx: commands.Context, user: Optional[discord.Member] = None):
    target = user or ctx.author
    if user is not None and not is_admin_member(ctx.author):
        await ctx.send(embed=error("Access Denied", "Only bot admins can manage another user's VM."))
        return
    rec = await owner_record(target.id)
    if not rec:
        await ctx.send(embed=warn("No VM Found", f"{target.mention} does not have an ATYRO VM."))
        return
    await ctx.send(embed=await management_embed(rec), view=ManageView(ctx.author.id, rec, int(rec["owner"])))


@bot.command(name="renew")
@commands.guild_only()
async def renew_cmd(ctx: commands.Context, user: discord.Member):
    if not is_admin_member(ctx.author):
        await ctx.send(embed=error("Access Denied", "Only bot admins can renew a VM."))
        return
    rec = await owner_record(user.id)
    if not rec:
        await ctx.send(embed=error("Not Found", f"{user.mention} has no VM."))
        return
    old_exp = parse_dt(rec["expires_at"])
    base = old_exp if old_exp > now_utc() else now_utc()
    rec["expires_at"] = iso(base + timedelta(days=LIFETIME_DAYS))
    try:
        await docker("start", rec["container"], check=False)
    except Exception:
        pass
    save_all()
    await ctx.send(embed=success("VM Renewed", f"{user.mention}'s VM has been extended by **{LIFETIME_DAYS} days**.\nNew expiry: `{rec['expires_at'][:10]}`"))


@bot.command(name="delete")
@commands.guild_only()
async def delete_cmd(ctx: commands.Context, user: discord.Member):
    if not is_admin_member(ctx.author):
        await ctx.send(embed=error("Access Denied", "Only bot admins can delete a VM."))
        return
    rec = await owner_record(user.id)
    if not rec:
        await ctx.send(embed=error("Not Found", f"{user.mention} has no VM."))
        return
    await delete_vm_record(rec)
    vms.pop(rec["id"], None)
    save_all()
    await remove_vm_role_if_needed(user)
    await ctx.send(embed=success("VM Deleted", f"Deleted `{rec['container']}` and its persistent `/vm` volume for {user.mention}."))


@bot.command(name="vminfo")
async def vminfo_cmd(ctx: commands.Context):
    if not is_admin_member(ctx.author):
        await ctx.send(embed=error("Access Denied", "Admin only."))
        return
    if not vms:
        await ctx.send(embed=info("VM Inventory", "No VMs are registered."))
        return
    e = embed(f"{E_CROWN} ATYRO VM INVENTORY", f"Total VMs: **{len(vms)}**", COLOR)
    lines = []
    for i, rec in enumerate(vms.values(), 1):
        st = await vm_status(rec)
        lines.append(
            f"**#{i}** <@{rec['owner']}> • `{rec['container']}`\n"
            f"{E_ONLINE if st == 'running' else E_OFFLINE} `{st}` • `{rec['ram_gb']}GB / {rec['cpu']}C / {rec['disk_gb']}GB` • SSH `{rec['ssh_port']}` • Exp `{rec['expires_at'][:10]}`"
        )
    e.description = "\n\n".join(lines)[:4096]
    await ctx.send(embed=e)


@bot.command(name="setadmin", aliases=["adminset"])
@commands.guild_only()
async def setadmin_cmd(ctx: commands.Context, user: discord.Member):
    if not is_admin_id(ctx.author.id):
        await ctx.send(embed=error("Access Denied", "Only the bot owner/admins can manage admins."))
        return
    admins.add(str(user.id))
    save_all()
    role = ctx.guild.get_role(BOT_ADMIN_ROLE_ID)
    if role:
        try:
            await user.add_roles(role, reason="ATYRO bot admin")
        except discord.HTTPException:
            pass
    await ctx.send(embed=success("Admin Added", f"{user.mention} is now an ATYRO bot admin."))


@bot.command(name="removeadmin")
@commands.guild_only()
async def removeadmin_cmd(ctx: commands.Context, user: discord.Member):
    if not is_admin_id(ctx.author.id):
        await ctx.send(embed=error("Access Denied", "Only the bot owner/admins can manage admins."))
        return
    if user.id == BOT_OWNER_ID:
        await ctx.send(embed=warn("Protected Account", "The bot owner cannot be removed."))
        return
    admins.discard(str(user.id))
    save_all()
    role = ctx.guild.get_role(BOT_ADMIN_ROLE_ID)
    if role:
        try:
            await user.remove_roles(role, reason="ATYRO bot admin removed")
        except discord.HTTPException:
            pass
    await ctx.send(embed=success("Admin Removed", f"{user.mention} is no longer a bot admin."))


@bot.command(name="help")
async def help_cmd(ctx: commands.Context):
    e = embed(f"{E_BOT} ATYRO CLOUD COMMANDS", "Premium Ubuntu VM management.", COLOR)
    e.add_field(name="VM", value="`!vm <ram> <cpu> <disk> @user`\n`!manage [@user]`\n`!renew @user`\n`!delete @user`\n`!vminfo`", inline=False)
    e.add_field(name="Admin", value="`!setadmin @user` / `!adminset @user`\n`!removeadmin @user`", inline=False)
    e.add_field(name="SSHX", value="Manage → **SSHX** opens the **Ubuntu QEMU guest**. The Docker wrapper shell is no longer exposed.", inline=False)
    await ctx.send(embed=e)


@tasks.loop(minutes=2)
async def expiry_loop():
    changed = False
    now = now_utc()
    for rec in list(vms.values()):
        try:
            if now >= parse_dt(rec["expires_at"]):
                status = await vm_status(rec)
                if status == "running":
                    await docker("stop", rec["container"], timeout=45, check=False)
                    changed = True
        except Exception:
            log.exception("expiry check failed for %s", rec.get("container"))
    if changed:
        save_all()


if __name__ == "__main__":
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN is missing. Put BOT_TOKEN=... in .env or environment.")
    bot.run(BOT_TOKEN)
